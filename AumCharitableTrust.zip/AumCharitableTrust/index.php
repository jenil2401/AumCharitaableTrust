<?php




?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/icon type" href="images/icon.jpg">
    <title>AUM CHARITABLE TRUST</title>
</head>

<body>
   
    <nav class="navbar h-nav ">
        <div class="logo"><img src="images/logo.png" alt="Logo"></div>
       
        <div  class="nav-list v-class">
        <ul>
           
          
            <li class="list-item"><a href="index.php">HOME</a></li>
            <li class="list-item"><a href="#about">ABOUT</a></li>
            <li class="list-item"><a href="donation.php">DONATION</a></li>
            <li class="list-item"><a href="#contact">CONTACT US</a></li>
        </ul>

          </div>
          
        
    </nav>
    <section class="home background " id="home">
        <box class="box">
            <div class="one">
                <h1>Make a difference for people<br>
                    who needs it the most</h1>
            </div>
            <div class="two">
                <button class="button" type="button" onclick="window.location.href='donation.php'">START WITH A
                    LITTLE</button>
            </div>

        </box>

    </section>
    <section class="backgroundd">
        <div class="donation-btn"><button onclick="window.location.href='donation.php'">DONATE NOW</button></div>
    </section>
    <section class="backgroundd third-section">
        <div class="one">
            <h1>Cause that need your
                urgent attention</h1>
        </div>
        <div class="two">
            <p> AUM Education and Charitable Trust is a NGO providing education and curriculum activities to the students<br>
			    of rural community so that they can enjoy their right of education and study to analyze the problems of the society<br>
				and meeting the demands to fulfill the unlimited desires of the citizens.</p>
        </div>

    </section>
    <section class="fourth-section backgroundd">
       
        <div class="card">
            <div class="card-item">
                <img class="card-img" src="images/card1.jpg" alt="">
                <p style="text-align: center;margin:5px 0px;font-family:sans-serif;">
                    Help<br> Uneducated & Rural<br>People.</p>
                <p style="color: gray;font-family: sans-serif;margin: 10px 0px;">Donated <b>2640000/3000000</b></p>
                <button class="card-btn" onclick="window.location.href='donation.php'" type="button">DONATE NOW</button>
            </div>
            <div class="card-item">
                <img class="card-img" src="images/card2.jpg" alt="">
                <p style="text-align: center;margin:5px 0px;font-family:sans-serif;">
                    Provide<br> them useful educational<br>resources.</p>
                <p style="color: gray;font-family: sans-serif;margin: 10px 0px;">Donated <b>500000/1000000</b></p>
                <button class="card-btn" onclick="window.location.href='donation.php'" type="button">DONATE NOW</button>
            </div>
            <div class="card-item">
                <img class="card-img" src="images/card3.jpg" alt="">
                <p style="text-align: center;margin:5px 0px;font-family:sans-serif;">
                    Help<br>Us To feed 3 time <br>Meal.</p>
                <p style="color: gray;font-family: sans-serif;margin: 10px 0px;">Donated <b>400000/500000</b></p>
                <button class="card-btn" onclick="window.location.href='donation.php'" type="button">DONATE NOW</button>
            </div>
            <div class="card-item"  >
                <img class="card-img" src="images/card4.png" alt="">
                <p style="text-align: center;margin:5px 0px;font-family:sans-serif;">
                    Help<br>Us To Provide Best facilities for great <br>Education.</p>
                <p style="color: gray;font-family: sans-serif;margin: 10px 0px;">Donated <b>200000/1000000</b></p>
                <button  class="card-btn" onclick="window.location.href='donation.php'" type="button">DONATE NOW</button>
            </div>
        </div >
        <!-- <div class="btn-one" style="display: none;"><button class="btn-one" >hola</button></div> -->
        
    </section >
    
    <section class="backgroundd" id="about" >
        <section class="fifth-section ">
            <h1 style="font-family: 'Ubuntu', sans-serif;">About Us</h1><br>
            <p style="align-items: left;font-family: 'Ubuntu', sans-serif;"> We are an Educational Trust registered as an NGO working in the field of Education and Training since 2003.<br><br>
			Our profile of work includes Tribal projects from Government for Vocational & Skill training which is Employment linked in various sectors of I.T., Electronics , Telecom. <br><br>

			We have been working under various departments of MORD for DDU-GKY and other Government Programs to enhance the Skills of rural un-employed youth with making him Employed. <br><br>
			We are also affiliated under Ministry of Skills and Empowerment for particular Skill set of courses. <br><br>
			We are also authorized university authorized centre of Executing and training for BBA, BCA, PGDCA, DCA, MSW and BSW Programs.</p><br><br>
            <p style="align-items: left;font-family: 'Ubuntu', sans-serif;">
                Address: <br>
				2nd Floor, Satguru Complex, Opp. Jain Society,
				Near Bus Stand, <br>
				Godhra-
				Panchmahal : 389001<br>
				Gujarat<br>
				Mobile No.: +91-9429451524</p><br>
            <p style="align-items: left;font-family: 'Ubuntu', sans-serif;">
                Our partnership with the Government of India and various State Governments, along with the
                persistent
                support from corporates, individual donors, and well-wishers have helped us to grow from serving just
                150
                children in 5 schools in 2004 to a huge number.
            </p><br>
            </section>



    </section>

    <section class="sixth-section">
        <div class="first">
            <h1 style="color:#ff5050;font-family:'Ubuntu', sans-serif; " class="heading">
                Support Right to Education
            </h1>
        </div>
        <div class="second">
            <img src="images/sixFirst.jpg" alt="students">
        </div>
    </section>
    <section class="seventh-section">
        <div class="first">
			<img src="images/sixthsecond.jpg" alt="">
        </div>
        <div class="second">
            <p>A donation of ₹1,000 a month can provide monthly basic<br> essentials to 1 child.</p>
            <p>
                Your support towards a children care will:
            </p>
            <div class="second-div">
                <div style="display:flex;margin-top: 20px;"><img class="icon" src="images/home2.PNG" alt="">
                    <div style="margin-left: 25px;margin-top: 25px;"><span class="span" style="line-height: 15px;">
                            <h1  class="span" style="color:#ff5050;font-family:'Ubuntu', sans-serif; ">Give them
                                Education & Facilities</h1>
                        </span>
                    </div>
                </div>
                <div style="display:flex;margin-top: 20px;"><img  class="icon" src="images/medicine.PNG" alt="">
                    <div style="margin-left: 25px;margin-top: 25px;"><span style="line-height: 15px;">
                            <h1  class="span" style="color:#ff5050;font-family:'Ubuntu', sans-serif;">Care and support
                            </h1>
                        </span>
                    </div>
                </div>

                <div style="display:flex;margin-top: 20px;"><img  class="icon" src="images/food.PNG" alt="">
                    <div style="margin-left: 25px;margin-top: 25px;"><span style="line-height: 15px;">
                            <h1  class="span" style="color:#ff5050;font-family:'Ubuntu', sans-serif; ">Give them
                                nutrition</h1>
                        </span>
                    </div>
                </div>

            </div>
        </div>
    </section>

  

    <section class="contact" id="contact">
        <h1>Contact Us</h1>
   
        <div class="form">
            <input class="form-input" type="text" name="name" id="name" placeholder="Enter your name">
            <input class="form-input" type="text" name="email" id="email" placeholder="Enter your email">
            <input class="form-input" type="number" name="phone" id="phone" placeholder="Enter your phone no">
            <textarea class="form-input" name="text-area" id="text-area" placeholder="Enter Your Concern Here!"
                cols="30" rows="10"></textarea>
            <div class="div-form-btn"> <button class="btn btn-form">SUBMIT</button> </div>
        </div>

    </section>

    <footer class=" text-footer">
        &copy; 2022 - AUM CHARITABLE TRUST - All Rights Reserved
    </footer>
    
                </body>

</html>